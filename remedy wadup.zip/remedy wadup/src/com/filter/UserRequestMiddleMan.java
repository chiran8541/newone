package com.filter;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.models.UserRequest;
import com.service.Service;

public class UserRequestMiddleMan extends HttpServlet{
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		doPost(req, res);
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		String priority = req.getParameter("priority");
		String summary = req.getParameter("summary");
		String details = req.getParameter("details");
		
		
		UserRequest u = new UserRequest(priority, summary, details);
		
		HttpSession session = req.getSession();
		String username = (String) session.getAttribute("username");
		Service.addDetails(u ,username);
		
		RequestDispatcher rd = req.getRequestDispatcher("views/ticket.jsp");
		rd.forward(req, res);
		
	}
}
