package com.models;

public class UserRequest {
	private
	String priority;
	String summary;
	String details;
	
	public UserRequest(){}

	public UserRequest(String priority, String summary, String details) {
		super();
		this.priority = priority;
		this.summary = summary;
		this.details = details;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}
	
	
}
